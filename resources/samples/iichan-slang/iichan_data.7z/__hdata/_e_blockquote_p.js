var xpath = require('xpath')
  , dom = require('xmldom').DOMParser
  , fs = require('fs');

var fromf = process.argv[2];
var tof = process.argv[3];

var fromc = fs.readFileSync(fromf).toString();
 
var doc = new dom().parseFromString(fromc);

var nodes = xpath.select("//blockquote/p/text()", doc);

var r = [];
for(var ni = 0; ni < nodes.length; ++ni)
  r.push(nodes[ni].toString());

rs = r.join('\n');

fs.writeFileSync(tof, rs);
